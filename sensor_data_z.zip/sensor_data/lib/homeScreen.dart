import 'package:flutter/material.dart';
import 'fetch.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({Key? key}) : super(key: key);

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        centerTitle: true,
        title: Text("Sensors Status"),
      ),
      body: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
        Padding(
          padding: const EdgeInsets.fromLTRB(0, 20.0, 0, 0),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            children: [
              GestureDetector(
                onTap: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(builder: (context) => const Fetch()),
                  );
                },
                child: Card(
                  elevation: 10.0,
                  child: Container(
                    height: 150.0,
                    width: 130.0,
                    child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Icon(Icons.lightbulb_outline_sharp),
                          SizedBox(
                            height: 10.0,
                          ),
                          Text("off/on"),
                        ]),
                  ),
                ),
              ),
              GestureDetector(
                onTap: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(builder: (context) => const Fetch()),
                  );
                },
                child: Card(
                  elevation: 10.0,
                  child: Container(
                    height: 150.0,
                    width: 130.0,
                    child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Icon(Icons.waves),
                          SizedBox(
                            height: 10.0,
                          ),
                          Text("Sound detection"),
                        ]),
                  ),
                ),
              )
            ],
          ),
        ),
        SizedBox(
          height: 10.0,
        ),
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
          children: [
            GestureDetector(
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => const Fetch()),
                );
              },
              child: Card(
                elevation: 10.0,
                child: Container(
                  height: 150.0,
                  width: 130.0,
                  child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Icon(Icons.man_rounded),
                        SizedBox(
                          height: 10.0,
                        ),
                        Text("Presence"),
                      ]),
                ),
              ),
            ),
            GestureDetector(
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => const Fetch()),
                );
              },
              child: Card(
                elevation: 10.0,
                child: Container(
                  height: 150.0,
                  width: 130.0,
                  child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Icon(Icons.radar),
                        SizedBox(
                          height: 10.0,
                        ),
                        Text("Motion Normal"),
                      ]),
                ),
              ),
            )
          ],
        ),
        SizedBox(
          height: 5.0,
        ),
        Center(
            child: Text(
          "ThingSpeak merge and Alarms",
          style: TextStyle(fontSize: 20.0, fontWeight: FontWeight.bold),
        )),
        SizedBox(
          height: 5,
        ),
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceAround,
          children: [
            Text("CMD sent "),
            SizedBox(
              width: 5,
            ),
            Text("Yes")
          ],
        ),
        SizedBox(
          height: 5,
        ),
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceAround,
          children: [
            Text("Status Received"),
            SizedBox(
              width: 3,
            ),
            Text("Yes")
          ],
        ),
        Padding(
          padding: const EdgeInsets.all(50.0),
          child: TextButton(
            onPressed: () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => const Fetch()),
              );
            },
            style: TextButton.styleFrom(backgroundColor: Colors.blue),
            child: Text(
              "Set Alarm",
              style: TextStyle(color: Colors.white),
            ),
          ),
        )
      ]),
    );
  }
}
